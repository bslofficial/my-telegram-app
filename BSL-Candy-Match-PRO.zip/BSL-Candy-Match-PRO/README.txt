BSL Candy Match - Production Setup Guide

1. Upload all files to GitHub Repository.
2. Enable GitHub Pages → main branch → root folder.
3. Use Firebase Config in firebase.js (already prefilled).
4. Telegram WebApp → BotFather → set WebApp URL: https://bslofficial.github.io/my-telegram-app/
5. Adsgram UnitID: bot-23742
6. Admin Panel: admin.html → approve/deny withdraw & check leaderboard.
7. Daily Reward + Spin Wheel included.
8. Test in browser first → then in Telegram WebApp.
9. Firebase Rules: firebase-rules.json → set in Realtime Database → Rules tab.